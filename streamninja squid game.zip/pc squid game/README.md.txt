welcome to streamninja squid game 
if you lose then yes then windows if you 
win then yes then you win good luck